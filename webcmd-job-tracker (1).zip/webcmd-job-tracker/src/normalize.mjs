/**
 * Every ATS spells statuses differently. We normalize into this fixed set
 * so the diff/alert logic downstream never has to know about vendors.
 */
export const CANONICAL_STATUSES = [
  "applied",
  "under_review",
  "interview",
  "offer",
  "rejected",
  "withdrawn",
  "unknown",
];

// Add to this map whenever a new vendor's wording shows up in the wild.
// Keys are lowercased, whitespace-collapsed raw status strings.
const STATUS_ALIASES = {
  // applied
  "application received": "applied",
  "application submitted": "applied",
  applied: "applied",
  new: "applied",

  // under review
  "in review": "under_review",
  "under review": "under_review",
  "under consideration": "under_review",
  reviewing: "under_review",
  screening: "under_review",

  // interview
  "interview requested": "interview",
  "interview scheduled": "interview",
  interviewing: "interview",
  "phone screen": "interview",
  onsite: "interview",

  // offer
  offer: "offer",
  "offer extended": "offer",
  hired: "offer",

  // rejected
  rejected: "rejected",
  "not selected": "rejected",
  declined: "rejected",
  "position filled": "rejected",
  closed: "rejected",

  // withdrawn (candidate-initiated)
  withdrawn: "withdrawn",
  "application withdrawn": "withdrawn",
};

function normalizeStatus(rawStatus) {
  if (!rawStatus) return "unknown";
  const key = String(rawStatus).trim().toLowerCase().replace(/\s+/g, " ");
  return STATUS_ALIASES[key] ?? "unknown";
}

/**
 * Normalize one raw row (whatever shape the webcmd adapter emitted) into
 * the canonical application-tracking schema this repo works with
 * everywhere else.
 *
 * @param {object} raw - a single row from `webcmd <adapter> <command> -f json`
 * @param {object} tracker - the config entry this row came from
 */
export function normalizeRow(raw, tracker) {
  return {
    trackerId: tracker.id,
    company: raw.company ?? tracker.company,
    role: raw.role ?? raw.position ?? raw.title ?? "Unknown role",
    appliedDate: raw.appliedDate ?? raw.applied_at ?? null,
    rawStatus: raw.status ?? null,
    status: normalizeStatus(raw.status),
    statusUpdatedAt: raw.statusUpdatedAt ?? raw.updatedAt ?? raw.status_updated_at ?? null,
    applicationUrl: raw.applicationUrl ?? raw.url ?? null,
    source: tracker.adapter,
  };
}

export function normalizeRows(rawRows, tracker) {
  if (!Array.isArray(rawRows)) return [];
  return rawRows.map((r) => normalizeRow(r, tracker));
}
