#!/usr/bin/env node
import { readFile } from "node:fs/promises";
import { existsSync } from "node:fs";
import { execFile } from "node:child_process";
import { promisify } from "node:util";

import { normalizeRows } from "./normalize.mjs";
import { loadPreviousState, saveState } from "./state.mjs";
import { diffRows, writeDashboard } from "./report.mjs";

const execFileAsync = promisify(execFile);

const CONFIG_PATH = process.env.WEBCMD_TRACKER_CONFIG ?? "config/config.json";

async function loadConfig() {
  if (!existsSync(CONFIG_PATH)) {
    console.error(
      `No config found at ${CONFIG_PATH}. Copy config/config.example.json to config/config.json and edit it first.`
    );
    process.exit(1);
  }
  const raw = await readFile(CONFIG_PATH, "utf8");
  return JSON.parse(raw);
}

/**
 * Shell out to the webcmd CLI for one tracker and return the parsed JSON
 * rows. This is the only place that talks to webcmd — everything else in
 * this repo is vendor-agnostic.
 */
async function runAdapter(tracker, profile) {
  const args = [tracker.adapter, tracker.command, ...(tracker.args ?? []), "-f", "json"];
  if (profile) {
    args.push("--profile", profile);
  }

  try {
    const { stdout } = await execFileAsync("webcmd", args, {
      maxBuffer: 10 * 1024 * 1024,
    });
    const parsed = JSON.parse(stdout);
    // webcmd's documented JSON shape wraps rows; support both a bare array
    // and a { rows: [...] } / { stories: [...] }-style envelope.
    if (Array.isArray(parsed)) return parsed;
    if (Array.isArray(parsed.rows)) return parsed.rows;
    const firstArrayField = Object.values(parsed).find((v) => Array.isArray(v));
    return firstArrayField ?? [];
  } catch (err) {
    console.error(`[${tracker.id}] webcmd call failed: ${err.message}`);
    console.error(
      `  → is the '${tracker.adapter}' adapter authored yet? See prompts/adapter-authoring.md.`
    );
    return null; // signals "skip this tracker this run" rather than wiping its state
  }
}

async function main() {
  const config = await loadConfig();
  const allCurrentRows = [];
  const allChanges = [];

  for (const tracker of config.trackers) {
    console.log(`\n▶ ${tracker.company} (${tracker.adapter} ${tracker.command})`);

    const rawRows = await runAdapter(tracker, config.profile);
    if (rawRows === null) continue; // adapter call failed; keep last known state untouched

    const currentRows = normalizeRows(rawRows, tracker);
    const previousRows = await loadPreviousState(tracker.id);

    const changes = diffRows(previousRows, currentRows);
    if (changes.length === 0) {
      console.log("  no changes");
    } else {
      for (const c of changes) console.log(`  • ${c.message}`);
    }

    allChanges.push(...changes);
    allCurrentRows.push(...currentRows);

    await saveState(tracker.id, currentRows);
  }

  const dashboardPath = await writeDashboard(allCurrentRows, allChanges);
  console.log(`\nDashboard written to ${dashboardPath}`);

  if (allChanges.length > 0) {
    console.log(`\n${allChanges.length} change(s) since last run.`);
  }
}

main().catch((err) => {
  console.error("Fatal error:", err);
  process.exit(1);
});
