import { readFile, writeFile, mkdir } from "node:fs/promises";
import { existsSync } from "node:fs";
import path from "node:path";

const STATE_DIR = path.join(process.cwd(), "state");

async function ensureStateDir() {
  if (!existsSync(STATE_DIR)) {
    await mkdir(STATE_DIR, { recursive: true });
  }
}

function statePath(trackerId) {
  return path.join(STATE_DIR, `${trackerId}.json`);
}

/**
 * Load the previously-seen rows for a tracker. Returns [] if this is the
 * first run (nothing to diff against yet).
 */
export async function loadPreviousState(trackerId) {
  const file = statePath(trackerId);
  if (!existsSync(file)) return [];
  try {
    const raw = await readFile(file, "utf8");
    return JSON.parse(raw);
  } catch (err) {
    console.warn(`[state] could not read/parse ${file}, treating as empty:`, err.message);
    return [];
  }
}

/**
 * Persist the current rows for a tracker so the next run can diff against
 * them.
 */
export async function saveState(trackerId, rows) {
  await ensureStateDir();
  await writeFile(statePath(trackerId), JSON.stringify(rows, null, 2), "utf8");
}
