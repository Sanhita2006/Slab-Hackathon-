import { writeFile } from "node:fs/promises";

const STATUS_LABEL = {
  applied: "Applied",
  under_review: "Under review",
  interview: "Interview",
  offer: "Offer",
  rejected: "Rejected",
  withdrawn: "Withdrawn",
  unknown: "Unknown",
};

/**
 * Compare previous vs current rows for a single tracker and return a list
 * of human-readable change events: new applications appearing, and status
 * transitions on ones we've already seen.
 */
export function diffRows(previousRows, currentRows) {
  const changes = [];
  const prevByKey = new Map(previousRows.map((r) => [rowKey(r), r]));
  const currentKeys = new Set();

  for (const row of currentRows) {
    const key = rowKey(row);
    currentKeys.add(key);
    const prev = prevByKey.get(key);

    if (!prev) {
      changes.push({
        type: "new",
        company: row.company,
        role: row.role,
        status: row.status,
        message: `New application tracked: ${row.company} — ${row.role} (${STATUS_LABEL[row.status]})`,
      });
    } else if (prev.status !== row.status) {
      changes.push({
        type: "status_change",
        company: row.company,
        role: row.role,
        from: prev.status,
        to: row.status,
        message: `${row.company} — ${row.role}: ${STATUS_LABEL[prev.status]} → ${STATUS_LABEL[row.status]}`,
      });
    }
  }

  for (const [key, prev] of prevByKey) {
    if (!currentKeys.has(key)) {
      changes.push({
        type: "disappeared",
        company: prev.company,
        role: prev.role,
        message: `No longer listed (may have been removed by the employer): ${prev.company} — ${prev.role}`,
      });
    }
  }

  return changes;
}

function rowKey(row) {
  return `${row.company}::${row.role}::${row.applicationUrl ?? ""}`;
}

/**
 * Render dashboard.md: the full current pipeline grouped by status, plus
 * a "recent changes" section at the top.
 */
export async function writeDashboard(allRows, allChanges, outPath = "dashboard.md") {
  const now = new Date().toISOString();
  const lines = [];

  lines.push("# Application Radar");
  lines.push("");
  lines.push(`_Last updated: ${now}_`);
  lines.push("");

  lines.push("## Recent changes");
  lines.push("");
  if (allChanges.length === 0) {
    lines.push("No changes since the last run.");
  } else {
    for (const c of allChanges) {
      lines.push(`- ${c.message}`);
    }
  }
  lines.push("");

  lines.push("## Pipeline");
  lines.push("");
  for (const status of ["interview", "offer", "under_review", "applied", "unknown", "rejected", "withdrawn"]) {
    const rows = allRows.filter((r) => r.status === status);
    if (rows.length === 0) continue;
    lines.push(`### ${STATUS_LABEL[status]} (${rows.length})`);
    lines.push("");
    lines.push("| Company | Role | Applied | Last updated | Source |");
    lines.push("|---|---|---|---|---|");
    for (const r of rows) {
      const link = r.applicationUrl ? `[link](${r.applicationUrl})` : "";
      lines.push(
        `| ${r.company} | ${r.role} | ${r.appliedDate ?? "—"} | ${r.statusUpdatedAt ?? "—"} | ${r.source} ${link} |`
      );
    }
    lines.push("");
  }

  await writeFile(outPath, lines.join("\n"), "utf8");
  return outPath;
}
