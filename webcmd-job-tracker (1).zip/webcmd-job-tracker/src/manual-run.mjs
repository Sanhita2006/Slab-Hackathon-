#!/usr/bin/env node
/**
 * Manual-entry mode.
 *
 * You don't need webcmd, Claude Code, or any agent harness for this path.
 * You maintain config/manual-applications.json by hand — one entry per
 * application, however you got the info (checking each portal yourself
 * every so often) — and this script gives you the same two things the
 * webcmd-automated path gives you:
 *
 *   1. Change detection: a diff against what you had last time, so you
 *      only have to look at what actually moved (interview scheduled,
 *      rejected, etc.) instead of re-reading everything.
 *   2. dashboard.md: your whole pipeline in one file, grouped by status.
 *
 * This is meant as an on-ramp: if you later get access to an agent
 * harness with webcmd wired in, you can author real adapters and switch
 * to `npm start` without changing anything else — normalize.mjs,
 * report.mjs, and state.mjs are shared between both paths.
 */
import { readFile } from "node:fs/promises";
import { existsSync } from "node:fs";

import { normalizeRow } from "./normalize.mjs";
import { loadPreviousState, saveState } from "./state.mjs";
import { diffRows, writeDashboard } from "./report.mjs";

const APPLICATIONS_PATH = process.env.WEBCMD_MANUAL_APPLICATIONS ?? "config/manual-applications.json";

async function loadApplications() {
  if (!existsSync(APPLICATIONS_PATH)) {
    console.error(
      `No manual applications file found at ${APPLICATIONS_PATH}.\n` +
        `Copy config/manual-applications.example.json to config/manual-applications.json and edit it with your real applications first.`
    );
    process.exit(1);
  }
  const raw = await readFile(APPLICATIONS_PATH, "utf8");
  return JSON.parse(raw);
}

function groupByTrackerId(rows) {
  const groups = new Map();
  for (const row of rows) {
    if (!row.trackerId) {
      console.warn(`Skipping a row with no "trackerId": ${JSON.stringify(row)}`);
      continue;
    }
    if (!groups.has(row.trackerId)) groups.set(row.trackerId, []);
    groups.get(row.trackerId).push(row);
  }
  return groups;
}

async function main() {
  const applications = await loadApplications();
  const grouped = groupByTrackerId(applications);

  const allCurrentRows = [];
  const allChanges = [];

  for (const [trackerId, rawRows] of grouped) {
    const company = rawRows[0]?.company ?? trackerId;
    console.log(`\n▶ ${company}`);

    const tracker = { id: trackerId, company, adapter: "manual" };
    const currentRows = rawRows.map((r) => normalizeRow(r, tracker));
    const previousRows = await loadPreviousState(trackerId);

    const changes = diffRows(previousRows, currentRows);
    if (changes.length === 0) {
      console.log("  no changes");
    } else {
      for (const c of changes) console.log(`  • ${c.message}`);
    }

    allChanges.push(...changes);
    allCurrentRows.push(...currentRows);

    await saveState(trackerId, currentRows);
  }

  const dashboardPath = await writeDashboard(allCurrentRows, allChanges);
  console.log(`\nDashboard written to ${dashboardPath}`);

  if (allChanges.length > 0) {
    console.log(`\n${allChanges.length} change(s) since last run.`);
  }
}

main().catch((err) => {
  console.error("Fatal error:", err);
  process.exit(1);
});
