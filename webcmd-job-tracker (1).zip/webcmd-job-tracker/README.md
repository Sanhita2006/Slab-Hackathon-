# Application Radar

**A webcmd-powered agent that tracks your job applications across every ATS you applied through — without re-browsing anything, ever.**

## The problem

If you're actively job hunting you're likely applying through 20–100 different
company career portals. Almost none of them have an API. To know where you
stand you have to log into each portal by hand, or point a browser agent at
each one and pay full navigation + reasoning cost *every time you check*.

The underlying trick: those 100 companies don't run 100 different systems.
They almost all sit on a small number of Applicant Tracking Systems —
Greenhouse, Lever, Workday, iCIMS, SmartRecruiters, Ashby, and a handful of
others. The "my applications" page for *every Greenhouse-hosted company*
shares the same DOM/API shape.

That's precisely what [webcmd](https://webcmd.dev) is built for: explore a
site once, let it compile what it learned into a deterministic, named CLI
command, then reuse that command — including against every other company
running the same ATS.

## Architecture

```
                     ┌─────────────────────────────────────┐
                     │   ONE-TIME LEARNING (per ATS, not    │
                     │   per company — do this a handful    │
                     │   of times total)                    │
                     │                                       │
   Agent (Claude) ───┼─▶ /skill:webcmd-browser               │
                     │   /skill:webcmd-browser-sitemap        │
                     │   /skill:webcmd-adapter-author          │
                     │                                       │
                     │   → produces webcmd greenhouse status  │
                     │     webcmd lever status                │
                     │     webcmd workday status               │
                     └───────────────┬───────────────────────┘
                                     │  saved to ~/.webcmd/clis/**
                                     ▼
                     ┌─────────────────────────────────────┐
                     │   EVERY RUN (cheap, deterministic,   │
                     │   no model reasoning needed)          │
                     │                                       │
   orchestrator.mjs ─┼─▶ webcmd greenhouse status --profile jobsearch -f json
                     │   webcmd lever status --profile jobsearch -f json
                     │   webcmd workday status --profile jobsearch -f json
                     │                                       │
                     │   → normalize → diff vs last run       │
                     │   → alert on status changes             │
                     │   → write dashboard.md                   │
                     └─────────────────────────────────────┘
```

This repo is the **orchestrator half**: the part that runs on a schedule
(cron, CI, or manually), calls whatever webcmd adapters exist, normalizes
their output into one schema, and tells you what actually changed since
last time — not just what your current status is everywhere.

The **adapter-authoring half** is one-time, interactive, and belongs to an
agent harness with real webcmd + browser access (Claude Code, Codex, etc.).
The exact prompts to give it are in [`prompts/adapter-authoring.md`](prompts/adapter-authoring.md).

## Why this is the right shape for webcmd specifically

- **Learn once, amortize across many companies.** You don't author 60
  adapters for 60 companies — you author ~6, one per ATS vendor, and every
  company on that vendor is covered for free.
- **Authenticated, recurring, low-variance.** This is a workflow you repeat
  weekly/daily forever, which is exactly where webcmd's "graduate from
  browser exploration to deterministic CLI" model pays for itself — per
  webcmd's own numbers, ~90% less token spend than re-exploring with a raw
  browser agent every run.
- **Structured output is the whole point.** You don't want a screenshot of
  your Greenhouse status page, you want `{company, role, status, updatedAt}`
  — which is exactly the "stable JSON output, named args" contract webcmd
  adapters are meant to produce.

## No agent harness? Track manually instead

Everything in this project except the browser step is still useful without
webcmd or Claude Code at all. If you don't have access to an agent harness
right now, use manual mode instead:

```bash
cp config/manual-applications.example.json config/manual-applications.json
```

Edit that file by hand — one entry per application, using whatever status
text you see when you check each portal yourself. Then:

```bash
npm run track
```

This gives you the same change-detection and `dashboard.md` the automated
path gives you — it just costs you re-checking each portal by hand instead
of webcmd doing it. When/if you get access to an agent harness later, follow
[`prompts/adapter-authoring.md`](prompts/adapter-authoring.md) and switch to
`npm start` — nothing else about the project changes, since
`normalize.mjs`, `report.mjs`, and `state.mjs` are shared by both paths.

## Setup (automated path — needs an agent harness like Claude Code)

### 1. Install webcmd and connect it to an agent harness (one-time)

Get the `webcmd` binary itself:

```bash
npm install -g @agentrhq/webcmd
```

Then wire the skills into your agent harness. Run this **from inside this
repo** so they land at project scope (`.claude/skills/`), where Claude Code
auto-discovers them the moment you open a session here:

```bash
webcmd skills add --provider claude --scope project
```

That installs 7 skills, notably `webcmd-usage` (orientation), `webcmd-browser`
(ad-hoc driving), and `webcmd-adapter-author` (the one
`prompts/adapter-authoring.md` is written for). If you'd rather register it
as a marketplace plugin instead, that also works:

```bash
claude plugin marketplace add agentrhq/webcmd
claude plugin install webcmd@webcmd
```

### 2. Check if an adapter for your ATS already exists before authoring one

The npm package ships the webcmd core and browser control, but no site
adapters by default — those live in a separate plugin catalog. Check before
spending a browser-exploration session on something that's already solved:

```bash
webcmd plugin search greenhouse -f json
webcmd plugin search lever -f json
webcmd plugin search workday -f json
```

If a match comes back, install it directly:

```bash
webcmd plugin install <installSource-from-search>
```

Only fall through to authoring a new adapter (step 3) for ATS vendors where
the catalog search comes up empty.

### 3. Author one adapter per ATS you have applications on that isn't already in the catalog (one-time per ATS)

Open your agent harness (e.g. Claude Code) and hand it the prompts in
[`prompts/adapter-authoring.md`](prompts/adapter-authoring.md), one ATS at a
time. Log into each portal in the real browser session webcmd drives so it
can capture the authenticated "my applications" flow. When it's done you'll
have commands like:

```bash
webcmd list -f json
# → webcmd greenhouse status
#   webcmd lever status
#   webcmd workday status
```

### 4. Configure your trackers

Copy the example config and fill in the companies/adapters you actually use:

```bash
cp config/config.example.json config/config.json
```

Each entry maps a company you applied to onto the ATS adapter that serves
it — see comments in the example file.

### 5. Run it

```bash
npm install
npm start
```

This runs every configured adapter, normalizes the rows, diffs them against
`state/<trackerId>.json` from the previous run, prints any changes, and
writes `dashboard.md` with your full current pipeline.

Put `npm start` on a daily cron (or a GitHub Action) and you get a running
changelog of your job search instead of having to re-check a dozen tabs.

## Files

| Path | What it does |
|---|---|
| `src/orchestrator.mjs` | Entry point. Reads config, shells out to `webcmd`, normalizes, diffs, reports. |
| `src/normalize.mjs` | Maps each ATS's raw field names/status vocabulary onto one canonical schema. |
| `src/report.mjs` | Renders `dashboard.md` and the console change summary. |
| `src/state.mjs` | Tiny JSON-file state store, one file per tracker, for diffing across runs. |
| `config/config.example.json` | Example tracker config — copy to `config.json` and edit. |
| `prompts/adapter-authoring.md` | Copy-paste prompts for the one-time webcmd adapter-authoring step. |

## Extending

Adding a new ATS or a same-ATS company you newly applied to is:
1. If it's a **new ATS**: run one adapter-authoring prompt, once.
2. If it's an **existing ATS, new company**: just add an entry to `config.json`
   — no new exploration needed. This is the whole point of the "learn once,
   amortize across companies" architecture above.
