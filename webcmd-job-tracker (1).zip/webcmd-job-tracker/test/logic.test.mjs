import test from "node:test";
import assert from "node:assert/strict";

import { normalizeRow, normalizeRows } from "../src/normalize.mjs";
import { diffRows } from "../src/report.mjs";

const tracker = { id: "acme-corp", company: "Acme Corp", adapter: "greenhouse" };

test("normalizeRow maps vendor status strings to canonical statuses", () => {
  assert.equal(normalizeRow({ status: "Under Consideration" }, tracker).status, "under_review");
  assert.equal(normalizeRow({ status: "Interview Scheduled" }, tracker).status, "interview");
  assert.equal(normalizeRow({ status: "Not Selected" }, tracker).status, "rejected");
  assert.equal(normalizeRow({ status: "Some Brand New Vendor Wording" }, tracker).status, "unknown");
  assert.equal(normalizeRow({}, tracker).status, "unknown");
});

test("normalizeRow falls back to tracker.company when the row has none", () => {
  const row = normalizeRow({ role: "Staff Engineer", status: "applied" }, tracker);
  assert.equal(row.company, "Acme Corp");
  assert.equal(row.role, "Staff Engineer");
});

test("normalizeRows skips non-array input gracefully", () => {
  assert.deepEqual(normalizeRows(null, tracker), []);
  assert.deepEqual(normalizeRows(undefined, tracker), []);
});

test("diffRows detects a brand-new application", () => {
  const previous = [];
  const current = [
    { company: "Acme", role: "Engineer", status: "applied", applicationUrl: "u1" },
  ];
  const changes = diffRows(previous, current);
  assert.equal(changes.length, 1);
  assert.equal(changes[0].type, "new");
});

test("diffRows detects a status transition", () => {
  const previous = [
    { company: "Acme", role: "Engineer", status: "applied", applicationUrl: "u1" },
  ];
  const current = [
    { company: "Acme", role: "Engineer", status: "interview", applicationUrl: "u1" },
  ];
  const changes = diffRows(previous, current);
  assert.equal(changes.length, 1);
  assert.equal(changes[0].type, "status_change");
  assert.equal(changes[0].from, "applied");
  assert.equal(changes[0].to, "interview");
});

test("diffRows reports no changes when nothing changed", () => {
  const rows = [{ company: "Acme", role: "Engineer", status: "applied", applicationUrl: "u1" }];
  const changes = diffRows(rows, rows);
  assert.equal(changes.length, 0);
});

test("diffRows detects a row disappearing entirely", () => {
  const previous = [{ company: "Acme", role: "Engineer", status: "applied", applicationUrl: "u1" }];
  const current = [];
  const changes = diffRows(previous, current);
  assert.equal(changes.length, 1);
  assert.equal(changes[0].type, "disappeared");
});
