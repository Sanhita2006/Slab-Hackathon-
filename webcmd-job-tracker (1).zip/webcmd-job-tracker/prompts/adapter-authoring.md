# Adapter-authoring prompts

**Before authoring anything**, check whether an adapter for the ATS already
exists in webcmd's plugin catalog — no point re-exploring a site someone
else already solved:

```bash
webcmd plugin search greenhouse -f json
webcmd plugin search lever -f json
webcmd plugin search workday -f json
webcmd plugin search <other-vendor> -f json
```

If a result comes back, just `webcmd plugin install <installSource>` and
skip straight to wiring it into `config/config.json`.

Only run the prompts below for ATS vendors where that search comes up
empty. Run each **once per ATS vendor**, in an agent harness that has
webcmd connected (Claude Code, Codex, etc. — not this orchestrator repo).
Each prompt follows webcmd's own authoring pattern: explore in a real
browser, capture the shape, then graduate it into a named, stable command.

Log into the portal yourself when the browser session opens — webcmd needs
to observe an authenticated "my applications" page at least once. This is
by design, not a workaround: webcmd's adapter-author skill requires human
handoff for login, MFA, and CAPTCHA on every ATS — the adapter code itself
never collects or types credentials. Expect the first run against each
portal to pause with an `action_required` prompt and a `verify_command`;
log in, tell the agent you're done, and it re-runs that command to confirm
before continuing.

---

## Greenhouse

```
Use webcmd to explore my Greenhouse "My Jobs" / application status page
(job-boards.greenhouse.io candidate portal). I'm logged in.

Then author a private webcmd adapter:
  Command: webcmd greenhouse status
  Profile: 'jobsearch'
  Output: stable JSON array with fields:
    company, role, appliedDate, status, statusUpdatedAt, applicationUrl
  It should work for any Greenhouse-hosted company, not just one — capture
  the shared candidate-portal structure, not a single employer's page.
  Include help text explaining the required login profile.
  Verify the command runs and returns real rows before finishing.
```

## Lever

```
Use webcmd to explore my Lever candidate application status page. I'm
logged in.

Author a private adapter:
  Command: webcmd lever status
  Profile: 'jobsearch'
  Output: stable JSON array with fields:
    company, role, appliedDate, status, statusUpdatedAt, applicationUrl
  Generalize to the shared Lever candidate portal, not one employer.
  Verify it returns real rows before finishing.
```

## Workday

```
Use webcmd to explore my Workday "My Applications" candidate home page.
I'm logged in. Note: Workday tenants vary more than Greenhouse/Lever, so
capture fallback paths for tenants with a slightly different layout.

Author a private adapter:
  Command: webcmd workday status
  Profile: 'jobsearch'
  Output: stable JSON array with fields:
    company, role, appliedDate, status, statusUpdatedAt, applicationUrl
  Declare the strategy and any known pitfalls (e.g. tenant-specific status
  label variants) so future runs can heal instead of silently failing.
  Verify it returns real rows before finishing.
```

## iCIMS / SmartRecruiters / Ashby / other

```
Use webcmd to explore my <VENDOR> candidate application status page. I'm
logged in.

Author a private adapter:
  Command: webcmd <vendor> status
  Profile: 'jobsearch'
  Output: stable JSON array with fields:
    company, role, appliedDate, status, statusUpdatedAt, applicationUrl
  Generalize to the vendor's shared candidate portal template if one exists.
  Verify it returns real rows before finishing.
```

---

## After authoring

Confirm what got registered:

```bash
webcmd list -f json
```

Then add matching entries to `config/config.json` in this repo — one entry
per **company**, pointing at the ATS **adapter** that serves it. See
`config/config.example.json` for the shape.

## Notes on status vocabulary

Every ATS uses different status strings ("In Review" vs "Under
Consideration" vs "Application Received"). Don't try to normalize this at
authoring time — leave `status` as the raw string from the site. Normalization
into a canonical set (`applied`, `under_review`, `interview`, `offer`,
`rejected`, `withdrawn`) happens once, centrally, in
`src/normalize.mjs` in this repo, so it's easy to extend when a new vendor's
wording shows up.
